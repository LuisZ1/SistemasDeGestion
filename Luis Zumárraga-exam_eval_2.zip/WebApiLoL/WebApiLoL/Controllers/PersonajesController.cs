﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApiLoL.Entidades;
using WebApiLoL.DAL;

namespace WebApiLoL.Controllers {
    [Route("api/[controller]")]
    public class PersonajesController : Controller {
        // GET api/values
        [HttpGet]
        public List<clsPersonaje> Get() {
            clsListados listadoPersonajes = new clsListados();
            return listadoPersonajes.listadoPersonajes();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public clsPersonaje Get(int id) {
            clsListados listadoPersonajes = new clsListados();
            return listadoPersonajes.datosPersonaje(id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] clsPersonaje personaje) {
            ManejadoraPersonajes.insertarPersonaje(personaje);
        }

     
        //public IActionResult PostV2([FromBody] clsPersonaje personaje) {
        //    string accept = Request.Headers["Content-Type"].ToString();
        //    if (accept != "application/json" && accept != "*/*")
        //        return StatusCode(415); //Unsupported Media Type
        //    else {
        //        bool ok = ManejadoraPersonajes.insertarPersonaje(personaje);

        //        if (ok) {
        //            return StatusCode(204);
        //        } else {
        //            return StatusCode(400);
        //        }
        //    }

        //}
 /**/
        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put([FromBody] clsPersonaje personaje) {
            ManejadoraPersonajes.alterPersonaje(personaje);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id) {
            ManejadoraPersonajes.deletePersonaje(id);
        }
    }
}
