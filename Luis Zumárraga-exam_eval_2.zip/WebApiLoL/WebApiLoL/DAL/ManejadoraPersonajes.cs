﻿using WebApiLoL.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using _13_WebApiPersonas_DAL;

namespace WebApiLoL.DAL {
    public class ManejadoraPersonajes {

        /// <summary>
        /// El metodo recibe un personaje y lo inserta en la base de datos de Personajes.
        /// </summary>
        /// <param name="personaje"></param>
        /// <returns>TRUE en caso de que se haya insertado</returns>
        public static bool insertarPersonaje(clsPersonaje personaje) {
            bool veredicto = false;
            int numberOfRows = -1;

            clsMyConnection conexion = new clsMyConnection();
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand command = new SqlCommand();
            SqlDataReader lector = null;

            try {
                //Obtener conexion
                sqlConnection = conexion.getConnection();

                //Definicion de los parametros del comando
                command.Parameters.Add("@nombre", System.Data.SqlDbType.VarChar).Value = personaje.nombre;
                command.Parameters.Add("@alias", System.Data.SqlDbType.VarChar).Value = personaje.alias;
                command.Parameters.Add("@vida", System.Data.SqlDbType.VarChar).Value = personaje.vida;
                command.Parameters.Add("@regeneracion", System.Data.SqlDbType.VarChar).Value = personaje.regeneracion;
                command.Parameters.Add("@danno", System.Data.SqlDbType.VarChar).Value = personaje.danno;
                command.Parameters.Add("@armadura", System.Data.SqlDbType.VarChar).Value = personaje.armadura;
                command.Parameters.Add("@velAtaque", System.Data.SqlDbType.VarChar).Value = personaje.velAtaque;
                command.Parameters.Add("@resistencia", System.Data.SqlDbType.VarChar).Value = personaje.resistencia;
                command.Parameters.Add("@velMovimiento", System.Data.SqlDbType.VarChar).Value = personaje.velMovimiento;
                command.Parameters.Add("@idCategoria", System.Data.SqlDbType.VarChar).Value = personaje.idCategoria;


                command.CommandText = "INSERT INTO [Personajes] VALUES (@nombre, @alias, @vida, @regeneracion, @danno, @armadura, @velAtaque, @resistencia, @velMovimiento, @idCategoria)";
                command.Connection = sqlConnection;

                numberOfRows = command.ExecuteNonQuery();

                if (numberOfRows > 0) {
                    veredicto = true;
                }

            } catch (SqlException ex) { throw ex; } finally {
                //Cerramos el lector y la conexion
                conexion.closeConnection(ref sqlConnection);

                if (lector != null)
                    lector.Close();
            }
            return veredicto;
        }

        /// <summary>
        /// El metodo modifica en la base de datos le personaje cuya id sea igual a
        /// la recibida con los datos del objeto clsPersonaje recibido
        /// </summary>
        /// <param name="id"></param>
        /// <param name="personaje"></param>
        /// <returns>true en caso de exito</returns>
        public static bool alterPersonaje(clsPersonaje personaje) {
            bool veredicto = false;
            int numberOfRows = -1;

            clsMyConnection conexion = new clsMyConnection();
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand command = new SqlCommand();
            SqlDataReader lector = null;

            try {
                //Obtener conexion
                sqlConnection = conexion.getConnection();
                command.CommandText = "UPDATE [dbo].[Personajes] SET [nombre]=@nombre, [alias]=@alias, [vida]=@vida, [regeneracion]=@regeneracion, [danno]=@danno, [armadura]=@armadura, [velAtaque]=@velAtaque, [resistencia]=@resistencia, [velMovimiento]=@velMovimiento, [idCategoria]=@idCategoria WHERE idPersonaje = @idPersonaje ";
                command.Connection = sqlConnection;

                //Definicion de los parametros del comando
                command.Parameters.Add("@idPersonaje", System.Data.SqlDbType.Int).Value = personaje.idPersonaje;
                command.Parameters.Add("@nombre", System.Data.SqlDbType.VarChar).Value = personaje.nombre;
                command.Parameters.Add("@alias", System.Data.SqlDbType.VarChar).Value = personaje.alias;
                command.Parameters.Add("@vida", System.Data.SqlDbType.Float).Value = personaje.vida;
                command.Parameters.Add("@regeneracion", System.Data.SqlDbType.Float).Value = personaje.regeneracion;
                command.Parameters.Add("@danno", System.Data.SqlDbType.Float).Value = personaje.danno;
                command.Parameters.Add("@armadura", System.Data.SqlDbType.Float).Value = personaje.armadura;
                command.Parameters.Add("@velAtaque", System.Data.SqlDbType.Float).Value = personaje.velAtaque;
                command.Parameters.Add("@resistencia", System.Data.SqlDbType.Float).Value = personaje.resistencia;
                command.Parameters.Add("@velMovimiento", System.Data.SqlDbType.Float).Value = personaje.velMovimiento;
                command.Parameters.Add("@idCategoria", System.Data.SqlDbType.Int).Value = personaje.idCategoria;

                numberOfRows = command.ExecuteNonQuery(); //Petaso bonito y no se porqué

                if (numberOfRows > 0) {
                    veredicto = true;
                }

            } catch (SqlException ex) { throw ex; } finally {
                //Cerramos el lector y la conexion
                conexion.closeConnection(ref sqlConnection);

                if (lector != null)
                    lector.Close();
            }
            return veredicto;
        }

        /// <summary>
        /// elimina un personaje cuya id coincida con la id recibida
        /// </summary>
        /// <param name="id"></param>
        /// <returns>true en caso de exito</returns>
        public static bool deletePersonaje(int id) {
            bool veredicto = false;
            int numberOfRows = -1;

            clsMyConnection conexion = new clsMyConnection();
            SqlConnection sqlConnection = new SqlConnection();
            SqlCommand command = new SqlCommand();
            SqlDataReader lector = null;

            try {
                //Obtener conexion
                sqlConnection = conexion.getConnection();

                //Definicion de los parametros del comando
                command.Parameters.Add("@idPersonaje", System.Data.SqlDbType.Int).Value = id;

                command.CommandText = "DELETE FROM Personajes WHERE idPersonaje = @idPersonaje";
                command.Connection = sqlConnection;

                numberOfRows = command.ExecuteNonQuery();

                if (numberOfRows > 0) {
                    veredicto = true;
                }

            } catch (SqlException ex) { throw ex; } finally {
                //Cerramos el lector y la conexion
                conexion.closeConnection(ref sqlConnection);

                if (lector != null)
                    lector.Close();
            }
            return veredicto;
        }
    }
}
