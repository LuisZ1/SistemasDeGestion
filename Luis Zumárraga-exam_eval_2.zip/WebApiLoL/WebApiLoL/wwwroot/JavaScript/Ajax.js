﻿window.onload = inicializar;

var datosPersonaje;
var btnGuardar;
var clsPersonaje = new Object();

function inicializar() {
    poblarDropDown();
    datosPersonaje = document.getElementById('datosPersonaje');
    datosPersonaje.style.display = "none";
    btnGuardar = document.getElementById('btnGuardar');
    btnGuardar.addEventListener("click", clickGuardar, false);
}

function poblarDropDown() {
    let dropdown = document.getElementById('selectorPersonaje');
    dropdown.length = 0;

    let defaultOption = document.createElement('option');
    defaultOption.text = 'Elija un personaje';
    defaultOption.value = 0;

    dropdown.add(defaultOption);
    dropdown.selectedIndex = 0;

    const url = 'http://localhost:53259/api/personajes';

    const request = new XMLHttpRequest();
    request.open('GET', url, true);

    request.onload = function () {
        if (request.status === 200) {
            const data = JSON.parse(request.responseText);
            let option;
            for (let i = 0; i < data.length; i++) {
                option = document.createElement('option');
                option.text = data[i].nombre;
                option.id = data[i].idPersonaje;
                option.value = data[i].idPersonaje;
                dropdown.add(option);
            }
        } else {
            // Error
        }
    }

    request.onerror = function () {
        console.error('An error occurred fetching the JSON from ' + url);
    };

    request.send();

    dropdown.onchange = function () {
        if (dropdown.selectedIndex != 0) {
            personajeSeleccionado(dropdown.selectedIndex);
        } else {
            datosPersonaje.style.display = "none"; //ocultar div
        }
    }
}

function personajeSeleccionado(personajeSeleccionado) {
    //mostrar datos
    datosPersonaje.style.display = "block";

    //Peticion api

    
    var url2 = 'http://localhost:53259/api/personajes/' + personajeSeleccionado;

    var requestPersonaje = new XMLHttpRequest();
    requestPersonaje.open('GET', url2);

    requestPersonaje.onreadystatechange = function () {
        if (requestPersonaje.status === 200 && this.readyState == 4) {
            var dataPersonaje = JSON.parse(requestPersonaje.responseText);
            //alert("hola");

            clsPersonaje = dataPersonaje;
            document.getElementById('nombre').value = clsPersonaje.nombre;
            document.getElementById('alias').value = dataPersonaje.alias;
            document.getElementById('vida').value = dataPersonaje.vida;
            document.getElementById('regeneracion').value = dataPersonaje.regeneracion;
            document.getElementById('danno').value = dataPersonaje.danno;
            document.getElementById('armadura').value = dataPersonaje.armadura;
            document.getElementById('velAtaque').value = dataPersonaje.velAtaque;
            document.getElementById('resistencia').value = dataPersonaje.resistencia;
            document.getElementById('velMovimiento').value = dataPersonaje.velMovimiento;
            //document.getElementById('idCategoria').value = dataPersonaje.nombre;

            //clickGuardar(clsPersonaje);
        } else {
            // Error
        }
    }

    requestPersonaje.onerror = function () {
        console.error('An error occurred fetching the JSON from ' + url);
    };

    requestPersonaje.send();
    
}

function clickGuardar() {

    alert("clic guardar");
     
    var miLlamada = new XMLHttpRequest();
    var json = JSON.stringify(clsPersonaje);
    miLlamada.open("PUT", "http://localhost:53259/api/personajes/" + clsPersonaje.idPersonaje);
    miLlamada.setRequestHeader('Content-type', 'application/json; charset=utf-8');

    miLlamada.onreadystatechange = function () {
        if (miLlamada.readyState < 4) { //No funciona bien
            alert("Ups");
        } else {
            if (miLlamada.readyState == 4 && miLlamada.status == 204) {
                alert("Todo OK");      
                inicializaPagina();
            }
        }
    };

    miLlamada.send(json);

}
